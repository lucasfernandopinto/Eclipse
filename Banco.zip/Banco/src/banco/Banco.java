package banco;

public class Banco {

    // Classe aninhada estática Conta
    public static class Conta {
        private int id;
        private String titular;
        private double saldo;

        // Construtor para inicializar os atributos
        public Conta(int id, String titular, double saldoInicial) {
            this.id = id;
            this.titular = titular;
            this.saldo = saldoInicial;
        }

        // Método para depositar um valor na conta
        public void depositar(double valor) {
            if (valor > 0) {
                saldo += valor;
                System.out.println("Depósito de R$" + valor + " realizado com sucesso.");
            } else {
                System.out.println("Valor de depósito inválido.");
            }
        }

        // Método para sacar um valor da conta
        public void sacar(double valor) {
            if (valor > 0 && saldo >= valor) {
                saldo -= valor;
                System.out.println("Saque de R$" + valor + " realizado com sucesso.");
            } else {
                System.out.println("Saldo insuficiente ou valor de saque inválido.");
            }
        }

        // Método para exibir detalhes da conta
        public void exibirDetalhes() {
            System.out.println("ID: " + id + ", Titular: " + titular + ", Saldo: R$" + saldo);
        }
    }
}
