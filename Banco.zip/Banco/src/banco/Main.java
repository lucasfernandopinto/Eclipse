package banco;

import banco.Banco.Conta;

public class Main {
	public static void main(String[] args) {
	    Conta conta1 = new Conta(1, "Alice", 1000.0);
	    Conta conta2 = new Conta(2, "Bob", 500.0);
	    Conta conta3 = new Conta(3, "Carol", 200.0);
	    
	    // Realizando operações de depósito e saque
	    conta1.depositar(200.0);
	    conta1.sacar(150.0);
	    conta2.depositar(100.0);
	    conta2.sacar(700.0);
	    conta3.depositar(300.0);
	    conta3.sacar(100.0);
	
	    // Exibindo detalhes das contas
	    conta1.exibirDetalhes();
	    conta2.exibirDetalhes();
	    conta3.exibirDetalhes();
	}
}
