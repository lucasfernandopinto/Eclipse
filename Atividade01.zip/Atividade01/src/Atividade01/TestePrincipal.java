package Atividade01;

public class TestePrincipal {
    public static void main(String[] args) {
       
        Principal principal = new Principal(10);

        Principal.Aninhada aninhada = principal.new Aninhada();

        aninhada.exibir();
    }
}
