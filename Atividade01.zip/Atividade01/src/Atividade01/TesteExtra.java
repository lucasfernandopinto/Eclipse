package Atividade01;

public class TesteExtra {
    public static void main(String[] args) {
        Extra extra = new Extra();

        extra.info();

        extra.operacao(10);

        extra.info();
    }
}
