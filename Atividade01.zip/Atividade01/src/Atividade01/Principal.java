package Atividade01;

public class Principal {
	
	private int valor;
	
	public Principal(int valor) {
		this.valor = valor;
	}

	public class Aninhada{
		public void exibir() {
			System.out.println("valor = " + valor);
		}
	}
}
