package Atividade01;

public class EmMetodo {
	public static void main(String a[]) {
		Extra extra = new Extra();
		extra.info();
		extra.operacao(10);
		extra.info();
	}
}

class Extra{
	private int total = 0;
	
	public void operacao(int v) {
		class Somador{
			public void soma(int v) {
				total += v;
			}
		}
		Somador s = new Somador();
		s.soma(v);
	}
	
	public void info() {
		System.out.println("total = " + total);
	}
}
