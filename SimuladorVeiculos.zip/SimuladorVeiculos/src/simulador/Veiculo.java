package simulador;

public interface Veiculo {
	void mover();
}
