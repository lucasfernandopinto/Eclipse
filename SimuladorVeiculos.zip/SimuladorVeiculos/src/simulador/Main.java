package simulador;

public class Main {
    public static void main(String[] args) {

        Veiculo carro = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("O carro está se movendo.");
            }
        };

        Veiculo bicicleta = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("A bicicleta está se movendo.");
            }
        };

        Veiculo caminhao = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("O caminhão está se movendo.");
            }
        };

        carro.mover();
        bicicleta.mover();
        caminhao.mover();
    }
}
